def word_count(text):
    return len(text.split())