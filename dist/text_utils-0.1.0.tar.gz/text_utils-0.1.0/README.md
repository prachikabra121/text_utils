#text-utils

A simple python package for basic text utilities

##installation

pip install text_utils


#3 usage

from text_utils import clean_text,word_count

text = " Hello   welcome   to   the world    of anlytics"


print(clean_text(text))